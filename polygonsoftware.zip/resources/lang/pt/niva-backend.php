<?php


return [


    'info' => 'Informações',
    'all' => 'Todos',
    'sort_by' => 'Ordenar por',
    'call_help' => 'Pedir ajuda:',
    'mail_us' => 'Envie para nós:',
    'our_address' => 'Nosso endereço:',
 
    'no_results' => 'Sem resultados',
    'search_text' => 'Pesquisar tema wordpress',
    'you_searched_for' => 'Você pesquisou por:',

    'view_project' => 'Ver projeto', 
    'load_more' => 'Carregue mais', 

    'home' => 'Casa', 
    'our_projects' => 'Nossos projetos', 
    'our_news' => 'Nossas Notícias', 
    'view_articles' => 'Ver todos os artigos',


];