Inquiry from: {{ $name }}
<p> Email: {{ $email }} </p>
<p> Phone: {{ $phone }} </p>
<p> Budget: {{ $budget }} </p>
<p> Message: {{ $comment }} </p>