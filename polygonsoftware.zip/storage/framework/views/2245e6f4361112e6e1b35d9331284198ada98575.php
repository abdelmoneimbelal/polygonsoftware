<?php $__env->startSection('title'); ?>
    <?php echo e($homesetting->meta_title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('meta'); ?>
    <?php echo e($homesetting->meta_description); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="slider-venor-section">
        <div class="slider-venor owl-carousel">

            <?php $count = 0; ?>
            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="slider-inner-venor <?php if($count == 0): ?> slider-count-0 <?php endif; ?>">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-5">
                                <div class="slider-content">
                                    <h1 <?php if($count == 0): ?> class="active" <?php endif; ?>><?php echo $slido->heading1; ?>

                                    </h1>
                                    <h2 <?php if($count == 0): ?> class="active" <?php endif; ?>><?php echo $slido->heading2; ?></h2>
                                    <div class="slider-body  <?php if($count == 0): ?> active <?php endif; ?>">
                                        <?php echo $slido->bodyslider; ?></div>

                                    <?php if($slido->button_text): ?>
                                        <div class="button-slider-b">
                                            <a href="<?php echo $slido->button_link; ?>" target="_self"
                                                class="btn btn-slider"><span><?php echo $slido->button_text; ?></span><svg
                                                    width="11.4" height="9.2">
                                                    <use xlink:href="#arrow"></use>
                                                </svg></a>
                                        </div>
                                    <?php endif; ?>

                                    <?php if($slido->button_text2): ?>
                                        <div class="button-slider-b button-slider-b2">
                                            <a href="<?php echo $slido->button_link2; ?>" target="_self"
                                                class="btn btn-slider"><span><?php echo $slido->button_text2; ?></span><svg
                                                    width="11.4" height="9.2">
                                                    <use xlink:href="#arrow"></use>
                                                </svg></a>
                                        </div>
                                    <?php endif; ?>

                                </div>
                            </div>

                            <div class="col-md-7">
                                <div class="slider-image">
                                    <div class="slider-image-inner">
                                        <img class="owl-lazy img-fluid slider-img"
                                            data-src="<?php echo e(asset('/images/media/' . $slido->photo->file)); ?>" alt="">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php $count++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="header-social-share">
            <?php echo $headerfooter->social_links; ?>

        </div>
        <a href="#" class="hero__scroll"><svg width="15" height="22.1">
                <use xlink:href="#scroll"></use>
            </svg></a>
    </div>

    <div class="about-section light-section">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="item-about">
                        <div class="item-about-row">
                            <div class="item-about-img2">
                                <div class="avo-image avo-tooltip about-img3 big-paral">
                                    <div class="simpleParallax imago"
                                        data-tooltip-tit="<?php echo e($homesetting->about_image3_titlu1); ?>"
                                        data-tooltip-sub="<?php echo e($homesetting->about_image3_titlu2); ?>"><img
                                            src="/public/img/loading-blog.gif" width="500" height="666"
                                            class="lazy thumparallax-down img-fluid"
                                            data-src="<?php echo e($homesetting->about_image3); ?>" alt="about-us" /></div>
                                </div>
                            </div>
                            <div class="item-about-img1">
                                <div class="avo-image avo-tooltip about-img1 big-paral">
                                    <div class="simpleParallax imago"
                                        data-tooltip-tit="<?php echo e($homesetting->about_image2_titlu1); ?>"
                                        data-tooltip-sub="<?php echo e($homesetting->about_image2_titlu2); ?>"><img
                                            src="/public/img/loading-blog.gif" width="500" height="666"
                                            class="lazy thumparallax-down img-fluid"
                                            data-src="<?php echo e($homesetting->about_image2); ?>" alt="about-us" /></div>
                                </div>
                                <div class="avo-image avo-tooltip about-img2 big-paral">
                                    <div class="simpleParallax imago"
                                        data-tooltip-tit="<?php echo e($homesetting->about_image1_titlu1); ?>"
                                        data-tooltip-sub="<?php echo e($homesetting->about_image1_titlu2); ?>"><img
                                            src="/public/img/loading-blog.gif" width="500" height="666"
                                            class="lazy thumparallax-down img-fluid"
                                            data-src="<?php echo e($homesetting->about_image1); ?>" alt="about-us" /></div>
                                </div>
                            </div>
                        </div>
                        <div class="exp-about">
                            <h5 class="nmb-font-about"><?php echo e($homesetting->about_yearstitle); ?></h5>
                            <h6 class="service_summary-about"><?php echo e($homesetting->about_yearstext); ?></h6>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <h4 class="about-heading1-home"><?php echo $homesetting->about_subtitle; ?></h4>
                    <h3 class="about-heading2-home"><?php echo $homesetting->about_title; ?></h3>
                    <?php echo $homesetting->about_description; ?>

                    <a href="<?php echo e($homesetting->about_buttonlink); ?>" target="_self"
                        class="btn btn-style1"><span><?php echo e($homesetting->about_buttontext); ?></span><svg width="11.4"
                            height="9.2">
                            <use xlink:href="#arrow"></use>
                        </svg></a>

                </div>
            </div>
        </div>
    </div>


    <div class="services-section light-section">
        <div class="container">

            <h3><?php echo $homesetting->services_title; ?></h3>

            <div class="description-services"><?php echo $homesetting->sevices_text; ?></div>

            <div class="service-boxes-slider owl-carousel">

                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card-parent">
                        <div class="card-inner-row">
                            <div class="card featured to-top-left">

                                
                                <div class="card-img">
                                    <img class="img-fluid project-image lazy" width="100" height="100"
                                        src="/img/loading-blog.gif "
                                        data-src="<?php echo e(asset('/images/media/' . $service->photo->file)); ?>"
                                        alt="<?php echo e($service->title); ?>">
                                </div>

                                <div class="heading-wrapper">
                                    <h4 class="heading"> <?php echo e($service->title); ?></h4>
                                </div>

                                <div class="paragraph-wrapper">
                                    <p class="paragraph"><?php echo e($service->description); ?></p>
                                </div>
                                

                            </div>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

        </div>
    </div>


    <div class="fun-facts-section light-section" id="fun-facts">
        <div class="container">

            <h3 class="fun-facts-heading1"><?php echo e($homesetting->fun_title); ?></h3>

            <p><?php echo e($homesetting->fun_description); ?></p>

            <div class="row fun-facts-timer">
                <div class="col-md-3">
                    <div class="radial">
                        <div class="radial-icon"><?php echo $homesetting->count_icon1; ?></div>
                        <span class="timer" data-from="0" data-to="<?php echo e($homesetting->count_number1); ?>"
                            data-speed="4000"><?php echo e($homesetting->count_number1); ?></span>
                        <h4><?php echo e($homesetting->count_description1); ?></h4>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="radial">
                        <div class="radial-icon"><?php echo $homesetting->count_icon2; ?></div>
                        <span class="timer" data-from="0" data-to="<?php echo e($homesetting->count_number2); ?>"
                            data-speed="4000"><?php echo e($homesetting->count_number2); ?></span>
                        <h4><?php echo e($homesetting->count_description2); ?></h4>
                    </div>

                </div>
                <div class="col-md-3">
                    <div class="radial">
                        <div class="radial-icon"><?php echo $homesetting->count_icon3; ?></div>
                        <span class="timer" data-from="0" data-to="<?php echo e($homesetting->count_number3); ?>"
                            data-speed="4000"><?php echo e($homesetting->count_number3); ?></span>
                        <h4><?php echo e($homesetting->count_description3); ?></h4>
                    </div>

                </div>
                <div class="col-md-3">
                    <div class="radial">
                        <div class="radial-icon"><?php echo $homesetting->count_icon4; ?></div>
                        <span class="timer" data-from="0" data-to="<?php echo e($homesetting->count_number4); ?>"
                            data-speed="4000"><?php echo e($homesetting->count_number4); ?></span>
                        <h4><?php echo e($homesetting->count_description4); ?></h4>
                    </div>
                </div>
            </div>


        </div>
    </div>

    <div class="portfolio-section">
        <div class="container">

            <h3><?php echo $homesetting->projects_title; ?></h3>
            <h4><?php echo e($homesetting->projects_subtitle); ?></h4>

            <div class="portfolio-slider owl-carousel">
                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="portfolio-slider-inner">
                        <div class="project-box-div">
                            <?php $count = $key + 1 ?>
                            <a href="<?php echo e(URL::to('/')); ?>/project/<?php echo e($project->slug); ?>" title="<?php echo e($project->title); ?>">
                                <img class="img-fluid project-image lazy" width="100%" height="400"
                                    style="height: 300px" src="<?php echo e(asset('/img/loading-blog.gif ')); ?>"
                                    data-src="<?php echo e(asset('/images/media/' . $project->photo->file)); ?>"
                                    alt="<?php echo e($project->title); ?>">
                            </a>
                            <div class="project-meta">

                                <div class="project-meta-title">
                                    <a href="<?php echo e(URL::to('/')); ?>/project/<?php echo e($project->slug); ?>"
                                        title="<?php echo e($project->title); ?>"><span
                                            class="project__text"><?php echo e($project->title); ?></span></a>
                                </div>

                                <div class="project-category">
                                    <span class="block_text"><?php echo e($project->project_category->name); ?> </span>
                                </div>

                            </div>
                        </div>
                    </div>

                    <?php if($key == 3): ?>
                    <?php break; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</div>

<div class="testimonial-section light-section">

    <div class="container">

        <h3><?php echo e($homesetting->testimonial_title); ?></h3>
        <p><?php echo e($homesetting->testimonial_subtitle); ?></p>

        <div class="testimonial-section-slider owl-carousel">

            <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <blockquote class="testimonial-slide">
                    <div class="testimonial-layout1">
                        <div class="item-figure">
                            <img class="img-fluid" width="90" height="90"
                                src="<?php echo e($testimonial->profile_pic ? $testimonial->profile_pic : '/public/img/200x200.png'); ?>"
                                alt="">
                        </div>
                        <div class="item-content">
                            <h3 class="item-title"><?php echo e($testimonial->name); ?></h3>
                            <div class="item-sub-title"><?php echo e($testimonial->position); ?></div>
                            <div class="item-paragraph"><?php echo $testimonial->description; ?></div>
                        </div>
                    </div>
                </blockquote>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </div>

</div>

















































<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\polygonsoftware\resources\views/home.blade.php ENDPATH**/ ?>