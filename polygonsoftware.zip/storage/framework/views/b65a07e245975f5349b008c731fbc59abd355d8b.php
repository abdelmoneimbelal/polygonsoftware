

<?php $__env->startSection('title'); ?> <?php echo e($page->meta_title); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('meta'); ?> <?php echo e($page->meta_description); ?> <?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
  
  


   <div class="breadcrumb-area">
        <div class="container">

               <h1 class="breadcrumb-title"><?php echo $page->meta_title; ?></h1>

               <ul class="shape-group-code">
                    <li class="shape shape-1">
                        <img src="img/bubble-9.png" alt="circle">
                    </li>
                    <li class="shape shape-2" >
                        <img src="img/bubble-17.png" alt="circle">
                    </li>
                    <li class="shape shape-3" >
                        <img src="img/line-4.png" alt="circle">
                    </li>
                </ul>
        </div>
   </div>

   <div class="page-content">
   		<div class="container">
   			<?php echo $page->body; ?>

   		</div>
   		
   </div>





<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/nanoshie/public_html/innowirx/resources/views/page.blade.php ENDPATH**/ ?>